# PL2_PAP
Repositorio para la segunda práctica de la asignatura Paradigmas Avanzados de Programación
